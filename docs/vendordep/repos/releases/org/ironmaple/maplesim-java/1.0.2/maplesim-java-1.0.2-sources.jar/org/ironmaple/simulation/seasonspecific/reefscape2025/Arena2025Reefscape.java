package org.ironmaple.simulation.seasonspecific.reefscape2025;

import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Pose3d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Translation2d;
import org.wpilib.driverstation.Alliance;
import java.util.Arrays;
import java.util.List;
import org.ironmaple.simulation.SimulatedArena;
import org.ironmaple.utils.FieldMirroringUtils;

/**
 *
 *
 * <h1>The playing field for the 2025 FRC Game: Reefscape</h1>
 *
 * <p>This class represents the playing field for the 2025 FRC game, Reefscape.
 *
 * <p>It extends {@link SimulatedArena} and includes specific details of the Reefscape game environment.
 */
public class Arena2025Reefscape extends SimulatedArena {
    public static final class ReefscapeFieldObstacleMap extends FieldMap {
        public ReefscapeFieldObstacleMap() {
            super();

            // blue wall
            super.addBorderLine(new Translation2d(0, 1.270), new Translation2d(0, 6.782));

            // blue coral stations
            super.addBorderLine(new Translation2d(0, 1.270), new Translation2d(1.672, 0));
            super.addBorderLine(new Translation2d(0, 6.782), new Translation2d(1.672, 8.052));

            // red wall
            super.addBorderLine(new Translation2d(17.548, 1.270), new Translation2d(17.548, 6.782));

            // red coral stations
            super.addBorderLine(new Translation2d(17.548, 1.270), new Translation2d(17.548 - 1.672, 0));
            super.addBorderLine(new Translation2d(17.548, 6.782), new Translation2d(17.548 - 1.672, 8.052));

            // upper walls
            super.addBorderLine(new Translation2d(1.672, 8.052), new Translation2d(11, 8.052));
            super.addBorderLine(new Translation2d(12, 8.052), new Translation2d(17.548 - 1.672, 8.052));

            // lower walls
            super.addBorderLine(new Translation2d(1.672, 0), new Translation2d(5.8, 0));
            super.addBorderLine(new Translation2d(6.3, 0), new Translation2d(17.548 - 1.672, 0));

            // blue reef
            Translation2d[] reefVorticesBlue = new Translation2d[] {
                new Translation2d(3.658, 3.546),
                new Translation2d(3.658, 4.506),
                new Translation2d(4.489, 4.987),
                new Translation2d(5.3213, 4.506),
                new Translation2d(5.3213, 3.546),
                new Translation2d(4.489, 3.065)
            };
            for (int i = 0; i < 6; i++) super.addBorderLine(reefVorticesBlue[i], reefVorticesBlue[(i + 1) % 6]);

            // red reef
            Translation2d[] reefVorticesRed = Arrays.stream(reefVorticesBlue)
                    .map(pointAtBlue ->
                            new Translation2d(FieldMirroringUtils.FIELD_WIDTH - pointAtBlue.getX(), pointAtBlue.getY()))
                    .toArray(Translation2d[]::new);
            for (int i = 0; i < 6; i++) super.addBorderLine(reefVorticesRed[i], reefVorticesRed[(i + 1) % 6]);

            // the pillar in the middle of the field
            super.addRectangularObstacle(0.305, 0.305, new Pose2d(8.774, 4.026, new Rotation2d()));
        }
    }

    public final ReefscapeReefSimulation redReefSimulation;
    public final ReefscapeReefSimulation blueReefSimulation;
    public final ReefscapeBargeSimulation redBarge;
    public final ReefscapeBargeSimulation blueBarge;
    public final ReefscapeProcessorSimulation redProcessor;
    public final ReefscapeProcessorSimulation blueProcessor;

    public Arena2025Reefscape() {
        super(new ReefscapeFieldObstacleMap());

        redReefSimulation = new ReefscapeReefSimulation(this, false);
        super.addCustomSimulation(redReefSimulation);

        blueReefSimulation = new ReefscapeReefSimulation(this, true);
        super.addCustomSimulation(blueReefSimulation);

        blueBarge = new ReefscapeBargeSimulation(this, true);
        super.addCustomSimulation(blueBarge);

        redBarge = new ReefscapeBargeSimulation(this, false);
        super.addCustomSimulation(redBarge);

        blueProcessor = new ReefscapeProcessorSimulation(this, true);
        super.addCustomSimulation(blueProcessor);

        redProcessor = new ReefscapeProcessorSimulation(this, false);
        super.addCustomSimulation(redProcessor);
    }

    @Override
    public void placeGamePiecesOnField() {
        Translation2d[] bluePositions = new Translation2d[] {
            new Translation2d(1.219, 5.855), new Translation2d(1.219, 4.026), new Translation2d(1.219, 2.197),
        };
        for (Translation2d position : bluePositions)
            getGamePieceManager().spawnOnField(new ReefscapeCoralAlgaeStack(position));

        Translation2d[] redPositions = Arrays.stream(bluePositions)
                .map(bluePosition ->
                        new Translation2d(FieldMirroringUtils.FIELD_WIDTH - bluePosition.getX(), bluePosition.getY()))
                .toArray(Translation2d[]::new);
        for (Translation2d position : redPositions)
            getGamePieceManager().spawnOnField(new ReefscapeCoralAlgaeStack(position));

        setupValueForMatchBreakdown("AlgaeInProcessor");
        setupValueForMatchBreakdown("AlgaeInNet");
        setupValueForMatchBreakdown("Auto/CoralScoredInAuto");
        setupValueForMatchBreakdown("CoralScoredOnLevel 1");
        setupValueForMatchBreakdown("CoralScoredOnLevel 2");
        setupValueForMatchBreakdown("CoralScoredOnLevel 3");
        setupValueForMatchBreakdown("CoralScoredOnLevel 4");
        setupValueForMatchBreakdown("Auto/AlgaeScoredInAuto");
    }

    @Override
    public synchronized List<Pose3d> getGamePiecesPosesByType(String type) {
        List<Pose3d> poses = super.getGamePiecesPosesByType(type);

        // add algae and coral stack
        if (type.equals("Algae")) {
            poses.addAll(ReefscapeCoralAlgaeStack.getStackedAlgaePoses());
            redBarge.draw(poses);
            blueBarge.draw(poses);

        } else if (type.equals("Coral")) {
            poses.addAll(ReefscapeCoralAlgaeStack.getStackedCoralPoses());
            redReefSimulation.draw(poses);
            blueReefSimulation.draw(poses);
        }

        return poses;
    }

    @Override
    public synchronized void clearGamePieces() {
        super.clearGamePieces();
        redReefSimulation.clearReef();
        blueReefSimulation.clearReef();
    }

    /**
     * Obtains the amount of <strong>CORAL</strong> held on the <strong>BRANCHES</strong>.
     *
     * <p>This method returns a 2D array of size 12 x 4, where each entry represents the number of
     * <strong>CORAL</strong>s held on a particular branch.
     *
     * <p>The <strong>BRANCHES</strong> are tracked in FMS as A, B, C, D, E, F, G, H, I, J, K, L (as per the game
     * manual), and are mapped to indices 0, 1, 2, ... in the array.
     *
     * <p>The [i][j] entry in the array represents the number of <strong>CORAL</strong>(s) held on the L<code>j-1</code>
     * branch in the <code>i</code>th section.
     *
     * <p>For example, <code>getBranches()[2][3]</code> returns the number of CORALs held on L4 of Branch C.
     *
     * <p>Note that L2, L3, and L4 can only hold one <strong>CORAL</strong>, while L1 can hold up to two
     * <strong>CORAL</strong>s.
     *
     * @param side the alliance side (Red or Blue) to check for CORAL counts
     * @return a 2D array where each entry represents the number of <strong>CORAL</strong> held on each branch
     */
    public int[][] getBranches(Alliance side) {
        return side == Alliance.RED ? redReefSimulation.getBranches() : blueReefSimulation.getBranches();
    }
}
